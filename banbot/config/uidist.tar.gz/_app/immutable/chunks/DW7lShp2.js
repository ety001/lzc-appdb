import{g as n}from"./4uquqB1J.js";const s=()=>"Refresh",t=()=>"刷新",f=(o={},e={})=>{const r=e.locale??n();return r==="en-US"?s():r==="zh-CN"?t():"refresh"};export{f as r};
