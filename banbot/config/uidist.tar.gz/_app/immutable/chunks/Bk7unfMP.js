import{g as e}from"./4uquqB1J.js";const n=()=>"Start Time",s=()=>"开始时间",i=(a={},r={})=>{const t=r.locale??e();return t==="en-US"?n():t==="zh-CN"?s():"start_time"};export{i as s};
