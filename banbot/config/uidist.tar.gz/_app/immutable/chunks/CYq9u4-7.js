import{g as r}from"./4uquqB1J.js";const s=()=>"Symbol",t=()=>"品种",c=(e={},n={})=>{const o=n.locale??r();return o==="en-US"?s():o==="zh-CN"?t():"symbol"};export{c as s};
