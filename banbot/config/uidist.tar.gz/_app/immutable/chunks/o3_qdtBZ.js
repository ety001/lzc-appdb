import{g as c}from"./4uquqB1J.js";const n=()=>"Search",s=()=>"搜索",o=(t={},e={})=>{const r=e.locale??c();return r==="en-US"?n():r==="zh-CN"?s():"search"};export{o as s};
