import{g as e}from"./4uquqB1J.js";const o=()=>"Documentation",c=()=>"文档",s=(r={},t={})=>{const n=t.locale??e();return n==="en-US"?o():n==="zh-CN"?c():"document"};export{s as d};
