import{g as r}from"./4uquqB1J.js";const s=()=>"Save",t=()=>"保存",c=(a={},n={})=>{const e=n.locale??r();return e==="en-US"?s():e==="zh-CN"?t():"save"};export{c as s};
