import{g as e}from"./4uquqB1J.js";const n=()=>"Strategy",s=()=>"策略",c=(a={},r={})=>{const t=r.locale??e();return t==="en-US"?n():t==="zh-CN"?s():"strategy"};export{c as s};
