import{g as t}from"./4uquqB1J.js";const o=()=>"Account",r=()=>"账户",a=(e={},n={})=>{const c=n.locale??t();return c==="en-US"?o():c==="zh-CN"?r():"account"};export{a};
