import{l as o,Q as f,v as i,n as p,B as c,o as d,w as h}from"./ChnLpuuu.js";function v(s,e,...t){var r=s,n=p,a;o(()=>{n!==(n=e())&&(a&&(c(a),a=null),a=i(()=>n(r,...t)))},f),d&&(r=h)}export{v as s};
