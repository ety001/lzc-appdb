import{g as t}from"./4uquqB1J.js";const r=()=>"End Time",o=()=>"结束时间",s=(i={},n={})=>{const e=n.locale??t();return e==="en-US"?r():e==="zh-CN"?o():"end_time"};export{s as e};
