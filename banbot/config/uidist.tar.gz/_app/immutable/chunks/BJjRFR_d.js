import{g as n}from"./4uquqB1J.js";const r=()=>"Data",e=()=>"数据",s=(o={},a={})=>{const t=a.locale??n();return t==="en-US"?r():t==="zh-CN"?e():"data"};export{s as d};
