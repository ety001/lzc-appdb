import{g as n}from"./4uquqB1J.js";const r=()=>"Total",e=()=>"总计",c=(a={},o={})=>{const t=o.locale??n();return t==="en-US"?r():t==="zh-CN"?e():"total"};export{c as t};
