import{g as o}from"./4uquqB1J.js";const c=()=>"Actions",r=()=>"操作",a=(s={},t={})=>{const n=t.locale??o();return n==="en-US"?c():n==="zh-CN"?r():"actions"};export{a};
