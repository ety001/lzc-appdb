import{g as e}from"./4uquqB1J.js";const n=()=>"Market",a=()=>"市场",s=(o={},t={})=>{const r=t.locale??e();return r==="en-US"?n():r==="zh-CN"?a():"market"};export{s as m};
