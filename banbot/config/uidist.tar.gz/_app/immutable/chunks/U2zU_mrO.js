import{g as r}from"./4uquqB1J.js";const t=()=>"Download",e=()=>"下载",l=(a={},n={})=>{const o=n.locale??r();return o==="en-US"?t():o==="zh-CN"?e():"download"};export{l as d};
