import{g as c}from"./4uquqB1J.js";const r=()=>"Config",t=()=>"配置",f=(e={},o={})=>{const n=o.locale??c();return n==="en-US"?r():n==="zh-CN"?t():"config"};export{f as c};
