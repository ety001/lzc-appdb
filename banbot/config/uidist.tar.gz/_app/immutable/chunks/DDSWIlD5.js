import{g as r}from"./4uquqB1J.js";const t=()=>"Kline",l=()=>"K线",c=(o={},e={})=>{const n=e.locale??r();return n==="en-US"?t():n==="zh-CN"?l():"kline"};export{c as k};
