import{g as n}from"./4uquqB1J.js";const r=()=>"Time",o=()=>"时间",s=(i={},e={})=>{const t=e.locale??n();return t==="en-US"?r():t==="zh-CN"?o():"time"};export{s as t};
