import{g as r}from"./4uquqB1J.js";const n=()=>"Total Profit",e=()=>"总收益",i=(a={},o={})=>{const t=o.locale??r();return t==="en-US"?n():t==="zh-CN"?e():"total_profit"};export{i as t};
