import{g as e}from"./4uquqB1J.js";const n=()=>"Load More",t=()=>"加载更多",c=(a={},r={})=>{const o=r.locale??e();return o==="en-US"?n():o==="zh-CN"?t():"load_more"};export{c as l};
