import{g as n}from"./4uquqB1J.js";const t=()=>"Query",u=()=>"查询",s=(o={},e={})=>{const r=e.locale??n();return r==="en-US"?t():r==="zh-CN"?u():"query"};export{s as q};
