import{g as e}from"./4uquqB1J.js";const o=()=>"Profit Rate",n=()=>"盈亏率",c=(a={},r={})=>{const t=r.locale??e();return t==="en-US"?o():t==="zh-CN"?n():"profit_rate"};export{c as p};
