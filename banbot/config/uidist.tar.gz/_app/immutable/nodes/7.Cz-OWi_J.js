import{t as P,a as x,f as ma}from"../chunks/CB5W-8RN.js";import{p as ha,h as B,b as f,f as wa,t as k,a as Ta,s as i,g as e,c as r,r as t,k as G,d as c,u as R,j as Wa,e as pa}from"../chunks/ChnLpuuu.js";import{s as m,d as Ga}from"../chunks/C0SaxjKW.js";import{e as ga,i as da}from"../chunks/R2T5bVpD.js";import{s as J,r as W,b as Ja}from"../chunks/QbSv_yVo.js";import{b as Xa,a as Za}from"../chunks/DuEmQidF.js";import{b as Sa}from"../chunks/DMDXhe1u.js";import{a as ae,s as ee,b as te}from"../chunks/CFLXbCUD.js";import{g as se,l as ba}from"../chunks/4uquqB1J.js";import{aQ as Da,aR as re,aS as ce,aT as _e,aU as ie,aV as oe,aW as ne,aX as le,aY as fe,aZ as me,a_ as pe,a$ as ge,b0 as de,b1 as be,b2 as ue,b3 as ve,b4 as $e,b5 as ye,b6 as xe,b7 as ke,b8 as he,b9 as we,ba as Te,bb as Se,bc as De,bd as Ce,be as Ue,bf as je,bg as Fe,bh as Be,bi as Pe,bj as Me,bk as Ve,bl as Oe,bm as Ae,bn as Le,bo as ze,bp as Ie,bq as Ye,br as qe,bs as Ee,bt as He,bu as Ke,bv as Ne,bw as Qe,bx as Re,by as We,bz as Ge,bA as Je,bB as Xe,bC as Ze,bD as at,bE as et,bF as tt,bG as st,bH as rt,bI as ct,bJ as _t,bK as it,bL as ot,bM as nt,bN as lt,bO as ft,bP as mt,bQ as pt,bR as gt,bS as dt,bT as bt,bU as ut,bV as vt,bW as $t,bX as yt,bY as xt,bZ as ua,b_ as kt,b$ as ht,c0 as wt,c1 as Tt,c2 as St,c3 as Dt,c4 as va,c5 as Ct,c6 as Ut,c7 as jt,c8 as Ft,c9 as Bt,ca as Pt,cb as Mt,cc as Vt,cd as Ot,ce as At,cf as Lt,cg as zt,ch as It,ci as Yt,cj as qt,ck as Et,cl as Ht,cm as Kt,cn as $a,co as Nt,cp as Qt,cq as Rt,cr as Wt,cs as Gt,ct as Jt,cu as Xt,cv as Zt,cw as as,cx as es,cy as ts,cz as ss,cA as rs,cB as cs,cC as _s,cD as is,cE as os,cF as ns,cG as ls,$ as fs,a0 as ms,cH as ps,cI as gs,cJ as ds,cK as bs}from"../chunks/DM-DiD7x.js";import{r as us}from"../chunks/DL5kbt9u.js";import{C as Ca,o as Ua}from"../chunks/wzOxE1bj.js";import{o as ja}from"../chunks/CDGmo90F.js";import{g as vs}from"../chunks/BxByhZUt.js";import{d as $s,g as ya}from"../chunks/qdMHlWI0.js";import{a as y}from"../chunks/C7H5M8Cc.js";import{M as xa}from"../chunks/Q9sW-JMb.js";import{s as ka}from"../chunks/BhtzLyqu.js";import{c as ys}from"../chunks/BeDkIG9E.js";var xs=P('<div class="flex justify-between items-center mb-4"><h3 class="text-lg font-semibold"> </h3> <label for="config-drawer" class="btn btn-sm btn-circle">✕</label></div> <a target="_blank" class="link"> </a> <!>',1);function ks($,d){ha(d,!0);const p=`name: local  # ${ce()}
env: prod  # ${_e()}
leverage: 2  # ${ie()}
limit_vol_secs: 5  # ${oe()}
put_limit_secs: 120  # ${ne()}
account_pull_secs: 60  # ${le()}
market_type: spot  # ${fe()}
contract_type: swap  # ${me()}
odbook_ttl: 1000  # ${pe()}
concur_num: 2  # ${ge()}
order_type: market  # ${de()}
stop_enter_bars: 20  # ${be()}
prefire: 0  # ${ue()}
margin_add_rate: 0.66  # ${ve()}
stake_amount: 15  # ${$e()}
stake_pct: 50  # ${ye()}
max_stake_amt: 5000  # ${xe()}
draw_balance_over: 0  # ${ke()}
charge_on_bomb: false # ${he()}
take_over_strat: ma:demo # ${we()}
close_on_stuck: 20  # ${Te()}
open_vol_rate: 1  # ${Se()}
min_open_rate: 0.5  # ${De()}
low_cost_action: ignore  # ${Ce()}
bt_net_cost: 15  # ${Ue()}
relay_sim_unfinish: false  # ${je()}
order_bar_max: 500  # ${Fe()}
ntp_lang_code: none  # ${Be()}
wallet_amounts:  # ${Pe()}
  USDT: 10000
stake_currency: [USDT, TUSD]  # ${Me()}
fatal_stop:  # ${Ve()}
  '1440': 0.1  # ${Oe()}
  '180': 0.2  # ${Ae()}
  '30': 0.3  # ${Le()}
fatal_stop_hours: 8  # ${ze()}
time_start: "20240701"  # ${Ie()}
time_end: "20250701"
run_timeframes: [5m]  # ${Ye()}
run_policy:  # ${qe()}
  - name: Demo  # ${Ee()}
    run_timeframes: [5m]  # ${He()}
    filters:  # ${Ke()}
    - name: OffsetFilter
      offset: 10
      limit: 30
    max_pair: 999  # ${Ne()}
    max_open: 10  # ${Qe()}
    max_simul_open: 0 # ${Re()}
    order_bar_max: 0  # ${We()}
    stake_rate: 1  # ${Ge()}
    stop_loss: 1  # ${Je()}
    dirt: any  # ${Xe()}
    pairs: [BTC/USDT:USDT]
    params: {atr: 15}
    pair_params:
      BTC/USDT:USDT: {atr:14}
    strat_perf:
      enable: false
strat_perf:
  enable: false  # ${Ze()}
  min_od_num: 5  # ${at()}
  max_od_num: 30  # ${et()}
  min_job_num: 10  # ${tt()}
  mid_weight: 0.2  # ${st()}
  bad_weight: 0.1  # ${rt()}
pairs:  # ${ct()}
- SOL/USDT:USDT
- UNFI/USDT:USDT
- SFP/USDT:USDT
pairmgr:
  cron: '25 1 0 */2 * *' # ${_t()}
  offset: 0  # ${it()}
  limit: 999  # ${ot()}
  force_filters: false # ${nt()}
  pos_on_rotation: hold  # ${lt()}
  use_latest: false  # ${ft()}
pairlists:  # ${mt()}
  - name: VolumePairList  # ${pt()}
    limit: 100  # ${gt()}
    min_value: 100000  # ${dt()}
    cache_secs: 7200  # ${bt()}
    back_period: 3d  # ${ut()}
  - name: PriceFilter
    max_unit_value: 100  # ${vt()}
    precision: 0.0015  # ${$t()}
    min: 0.001  # ${yt()}
    max: 100000  # ${xt()}
  - name: RateOfChangeFilter
    back_days: 5  # ${ua()}
    min: 0.03  # ${kt()}
    max: 10  # ${ht()}
    cache_secs: 1440  # ${wt()}
  - name: SpreadFilter  # ${Tt()}
    max_ratio: 0.005  # ${St()}
  - name: CorrelationFilter  # ${Dt()}
    min: -1  # ${va()}
    max: 1  # ${va()}
    timeframe: 5m  # ${Ct()}
    back_num: 70  # ${Ut()}
    sort: asc  # asc/desc/""
    top_n: 50  # ${jt()}
  - name: VolatilityFilter  # ${Ft()}
    back_days: 10  # ${ua()}
    max: 1  # ${Bt()}
    min: 0.05  # ${Pt()}
  - name: AgeFilter  # ${Mt()}
    min: 5
  - name: OffsetFilter  # ${Vt()}
    reverse: false  # reverse array
    offset: 10
    rate: 0.5  # 50% of array
    limit: 30
  - name: ShuffleFilter  # ${Ot()}
    seed: 42
accounts:
  user1:  # ${At()}
    no_trade: false  # ${Lt()}
    stake_rate: 1  # ${zt()}
    leverage: 0  # ${It()}
    max_stake_amt: 0  # ${Yt()}
    max_pair: 0  # ${qt()}
    max_open_orders: 0  # ${Et()}
    binance:
      prod:  # ${Ht()}
        api_key: vvv
        api_secret: vvv
      test:  # ${Kt()}
        api_key: vvv
        api_secret: vvv
    rpc_channels:  # ${$a()}
      - name: wx_bot
        to_user: ChannelUserID
    api_server:  # ${Nt()}
      pwd: abc
      role: admin
exchange:
  name: binance  # ${Qt()}
  binance:  # ${Rt()}
    fees:
      linear:
        taker: 0.0005
        maker: 0.0002
database:
  retention: all
  max_pool_size: 50
  auto_create: true  # ${Wt()}
  url: postgresql://postgres:123@[127.0.0.1]:5432/ban
spider_addr: 127.0.0.1:6789  # ${Gt()}
rpc_channels:  # ${$a()}
  wx_notify:  # ${Jt()}
    corp_id: ww0f12345678b7e
    agent_id: '1000005'
    corp_secret: b123456789_1Cx1234YB9K-MuVW1234
    touser: '@all'
    type: wework  # ${Xt()}
    msg_types: [exception]  # ${Zt()}
    accounts: []  # ${as()}
    keywords: []  # ${es()}
    retry_num: 0
    retry_delay: 1000
    disable: true
webhook:  # ${ts()}
  entry:
    content: "{name} {action}\\nSymbol: {pair} {timeframe}\\nTag: {strategy}  {enter_tag}\\nPrice: {price:.5f}\\nCost: {value:.2f}"
  exit:
    content: "{name} {action}\\nSymbol: {pair} {timeframe}\\nTag: {strategy}  {exit_tag}\\nPrice: {price:.5f}\\nCost: {value:.2f}\\nProfit: {profit:.2f}"
  status:  # ${ss()}
    content: '{name}: {status}'
  exception:
    content: '{name}: {status}'
api_server:  # ${rs()}
  enable: true
  bind_ip: 127.0.0.1  # ${cs()}
  port: 8001
  jwt_secret_key: fn234njkcu89234nbf
  users:
    - user: ban
      pwd: 123
      allow_ips: []
      acc_roles: {user1: admin}
`;let h=B(Ua),b=f(null);ja(()=>{e(b)?e(b).setValue("config.yml",p):setTimeout(()=>{var g;(g=e(b))==null||g.setValue("config.yml",p)},10)});var C=xs(),w=wa(C),u=r(w),U=r(u,!0);t(u),G(2),t(w);var l=i(w,2),T=r(l,!0);t(l);var S=i(l,2);Sa(Ca(S,{get theme(){return h},editable:!1}),g=>c(b,g,!0),()=>e(b)),k((g,D,n)=>{m(U,g),J(l,"href",`https://docs.banbot.site/${D??""}/guide/configuration.html`),m(T,n)},[()=>Da(),se,()=>re()]),x($,C),Ta()}async function hs($,d,p,h){d().dirtyBin?c(p,!0):await h()}var ws=($,d,p)=>d(e(p)),Ts=P('<div class="px-2 py-1 rounded cursor-pointer hover:bg-primary hover:bg-opacity-10 transition-all duration-200 text-sm"> </div>'),Ss=($,d,p)=>c(d,e(p),!0),Ds=P('<input type="radio" class="tab">'),Cs=P('<!> <!> <div class="drawer drawer-end"><input id="config-drawer" type="checkbox" class="drawer-toggle"> <div class="drawer-content"><div class="container mx-auto px-4 py-6"><div class="flex gap-6"><div class="w-[15%] bg-base-200 rounded-lg p-3"><h2 class="text-lg font-bold mb-2 text-primary"> </h2> <div class="mb-3"><input type="text" placeholder="Search ..." class="input input-sm"></div> <div class="space-y-0.5"></div></div> <div class="flex-1"><div class="flex justify-between items-center mb-6"><h2 class="text-2xl font-bold"> </h2> <a class="btn btn-outline"> </a></div> <div class="mb-12"><div class="flex justify-between items-center mb-2"><div><div class="tabs tabs-box tabs-sm"></div> <p class="mt-2 text-sm opacity-70"> </p></div> <label for="config-drawer" class="link link-primary cursor-pointer"> </label></div> <!></div> <div class="flex gap-4 fixed bottom-0 left-0 right-0 p-2 w-[100%] bg-white flex justify-center"><button class="btn btn-primary w-[50%]"> </button></div></div></div></div></div> <div class="drawer-side"><label for="config-drawer" aria-label="close sidebar" class="drawer-overlay"></label> <div class="bg-base-200 min-h-full w-2/3 p-4"><!></div></div></div>',1);function Rs($,d){ha(d,!0);const[p,h]=ee(),b=()=>ae(ka,"$site",p);let C=!1,w=B(Ua),u=f(null),U=f(!1),l=f(""),T=f(!1),S=f(!1),g=f(!1),D=f(""),n=f(""),v=B({}),M=f(B([])),j=f(""),Fa=R(()=>e(j)?e(M).filter(a=>a.toLowerCase().includes(e(j).toLowerCase())):e(M));ja(async()=>{let a=await ya("/dev/available_strats");if(a.code!=200){y.error(a.msg||"load strats failed");return}c(M,a.data,!0);let s=["config.yml","config.local.yml"].map(o=>"@"+o);if(a=await ya("/dev/texts",{paths:s}),a.code!=200){y.error(a.msg||"load config failed");return}s.forEach(o=>{a[o]&&(c(n,o.substring(1),!0),v[e(n)]=a[o],c(l,a[o],!0))}),e(u)&&e(u).setValue(e(n),e(l))}),Wa(()=>{e(n)&&setTimeout(function(){var a;c(l,v[e(n)],!0),(a=e(u))==null||a.setValue(e(n),e(l))},100)});async function Ba(a){c(l,a,!0),v[e(n)]=a}async function V(){if(!e(l)){y.error("config is empty");return}const a={};for(const s in v)v.hasOwnProperty(s)&&(a[`@${s}`]=v[s]);const _=await $s("/dev/run_backtest",{separate:C,configs:a,dupMode:e(D)});if(_.code===400&&_.msg==="[-18] already_exist"){c(T,!0);return}_.code===200?(y.success(_s()),vs(ba("/backtest"))):(console.error("run backtest fail",_),y.error(_.msg||"run backtest fail"))}async function Pa(a){if(c(T,!1),a==="backup_start")c(D,"backup");else if(a==="overwrite_start")c(D,"overwrite");else return;V()}async function Ma(a){c(S,!1),a=="compile"?(c(g,!0),await ys(),c(g,!1)):a=="just_backtest"&&(te(ka,pa(b).dirtyBin=!1,pa(b)),await V())}async function Va(a){await navigator.clipboard.writeText(a),y.success(bs())}var X=Cs(),Z=wa(X);const Oa=R(()=>gs());xa(Z,{get title(){return e(Oa)},buttons:["backup_start","overwrite_start","cancel"],get show(){return e(T)},click:Pa,center:!0,width:600,children:(a,_)=>{G();var s=ma();k(o=>m(s,o),[()=>is()]),x(a,s)},$$slots:{default:!0}});var aa=i(Z,2);const Aa=R(()=>ds());xa(aa,{get title(){return e(Aa)},buttons:["compile","just_backtest","cancel"],get show(){return e(S)},click:Ma,center:!0,width:400,children:(a,_)=>{G();var s=ma();k(o=>m(s,o),[()=>os()]),x(a,s)},$$slots:{default:!0}});var ea=i(aa,2),O=r(ea);W(O);var A=i(O,2),ta=r(A),sa=r(ta),L=r(sa),z=r(L),La=r(z,!0);t(z);var I=i(z,2),ra=r(I);W(ra),t(I);var ca=i(I,2);ga(ca,21,()=>e(Fa),da,(a,_)=>{var s=Ts();s.__click=[ws,Va,_];var o=r(s,!0);t(s),k(()=>m(o,e(_))),x(a,s)}),t(ca),t(L);var _a=i(L,2),Y=r(_a),q=r(Y),za=r(q,!0);t(q);var E=i(q,2),Ia=r(E,!0);t(E),t(Y);var H=i(Y,2),K=r(H),N=r(K),Q=r(N);ga(Q,21,()=>Object.keys(v),da,(a,_)=>{var s=Ds();W(s),s.__click=[Ss,n,_],k(()=>{J(s,"aria-label",e(_)),Ja(s,e(n)===e(_))}),x(a,s)}),t(Q);var ia=i(Q,2),Ya=r(ia,!0);t(ia),t(N);var oa=i(N,2),qa=r(oa,!0);t(oa),t(K);var Ea=i(K,2);Sa(Ca(Ea,{change:Ba,get theme(){return w},class:"flex-1 h-full"}),a=>c(u,a,!0),()=>e(u)),t(H);var na=i(H,2),F=r(na);F.__click=[hs,b,S,V];var Ha=r(F,!0);t(F),t(na),t(_a),t(sa),t(ta),t(A);var la=i(A,2),fa=i(r(la),2),Ka=r(fa);ks(Ka,{}),t(fa),t(la),t(ea),k((a,_,s,o,Na,Qa,Ra)=>{m(La,a),m(za,_),J(E,"href",s),m(Ia,o),m(Ya,Na),m(qa,Qa),F.disabled=e(g),m(Ha,Ra)},[()=>ns(),()=>us(),()=>ba("/backtest"),()=>ls(),()=>e(n)==="config.local.yml"?fs():ms(),()=>Da(),()=>ps()]),Xa(O,()=>e(U),a=>c(U,a)),Za(ra,()=>e(j),a=>c(j,a)),x($,X),Ta(),h()}Ga(["click"]);export{Rs as component};
