## [stoploss](stoploss.go)
Demonstrate how to set a stop loss when opening an order, update the stop loss at each bar, and update the stop loss in a smaller period

## [takeprofit](takeprofit.go)
Demonstrate how to set a take profit when opening an order, update the take profit at each bar, and update the take profit in a smaller period
